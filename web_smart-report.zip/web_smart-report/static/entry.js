// 接口地址
const MainUrl = "http://127.0.0.1";
const MainPort = 8098;
const Developer = "asd";
const TechnicalSupport = "asdas";

const user = {
  username: "",
  id: 0,
  studentId: "",
  name: "",
  sex: 0,
  password: "***",
  idCard: "",
  collegeId: 0,
  majorId: 0,
  classId: 0,
  role: 0,
  grade: 0,
};
export default {
  MainUrl,
  MainPort,
  Developer,
  TechnicalSupport,
};
